# GrowPy

## Project Description

For questions and comments contact the developer directly at: <seilis@unbc.ca>.


## Installation
GrowPy is available through [PyPi](https://pypi.org/project/growpy/), and can be installed via `pip` using
```
pip install growpy
```
or 
```
pip3 install growpy
```

## Example Usage


## License

